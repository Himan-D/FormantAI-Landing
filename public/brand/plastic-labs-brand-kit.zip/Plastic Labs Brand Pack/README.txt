PLASTIC LABS — LOGO PACK

CONTENTS

  horizontal/   logo + wordmark, side by side
  stacked/      logo above wordmark
  preview.png   all variants at a glance

  Each lockup comes as SVG (vector — scales to any size, use when
  possible) and PNG (transparent background, high resolution).

COLORS

  black   #0F0F10   for light backgrounds
  white   #FFFFFF   for dark backgrounds
  green   #C0FFE1   brand accent, for dark backgrounds

  Note: the white and green files will look blank against a white
  preview window — they are intended for dark surfaces.

USAGE

  PNGs are cropped tight to the artwork (no built-in padding).
  Please keep clear space around the mark, keep colors as provided,
  and do not stretch, restyle, or add effects.

Plastic Labs — plasticlabs.ai
